package sample;

public class Product {

    private String productName;
    private String  quantity;
    private double price;
    private String productInfo[];

    public Product(String productString) {
        String dilimiter = ",";
        if ((productString.indexOf(dilimiter)) == -1) {
            productName = productString;
            quantity = " 0 ";
        } else {
            productInfo = productString.trim().split(dilimiter);
            productName = productInfo[0];
            quantity = productInfo[1];
        }
    }
    public String getProductName(){
        return productName;
    }
    public String getQuantity(){
        return quantity;
    }

    public void setQuantity(String newQuantity){
        this.quantity = newQuantity;
    }
    public double getPrice(){
        return price;
    }

}

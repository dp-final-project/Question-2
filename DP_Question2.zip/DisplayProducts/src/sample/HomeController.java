package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HomeController {
    @FXML Tab customerTab;
    @FXML Tab executiveTab;
    @FXML Tab purchaseTab;

    @FXML private ListView productList;

    @FXML private TableView tableView;
    @FXML private TableColumn productNameColumn;
    @FXML private TableColumn quantityColumn;

    @FXML private CheckBox sortList;
    @FXML private CheckBox sortTable;

    @FXML private Label listStatus;
    @FXML private Label tableStatus;



    public void setCustomerTab(){
        listChecked();
    }

    public void setExecutiveTab(){
       tableCheked();
    }
    public void setPurchaseTab() {

        System.out.println("Purchase Tab");
    }

    //fetches the product data needed to be displayed
    public Product[] getData(){

        String productsString[] = {"3Demon , 20", "YouthZest, 100" , "Urban She", "A Brisket" , "Tasket, 52", "Lazy Fair, 15",
                "Aromantic", "Vulvax, 36", "Titonic, 200", "Toe Food, 12", "Bookmaker", "Diamantra, 78", "Meteor Media, 10" , "SkinGear"};
        int size = productsString.length;
        Product products[] = new Product[size];

        for(int i =0; i < size ; i++){
            products[i] = new Product(productsString[i]);
        }
        return products;
    }

    /****************************************************Customer View ****************************************************/

    public void sortedList(){
        productList.getItems().clear();
        Product products[] = getData();
        Display sortedView = new DisplaySorted(new CustomerView());
        sortedView.addData(products);
        String names[];
        names = sortedView.addData(products);

        for(int i = 0; i < names.length ; i++){
            productList.getItems().add(names[i]);
        }
    }
    public void unsortedList(){
        productList.getItems().clear();
        Product products[] = getData();
        Display customerView = new DisplayProducts(new CustomerView());
        String names[];
        names = customerView.addData(products);

        for(int i = 0; i < names.length ; i++){
            productList.getItems().add(names[i]);
        }
    }
    public void listChecked(){
        if(sortList.isSelected()){
            listStatus.setText("Product List sorted alphabetically");
            sortedList();
        }else {
            listStatus.setText("Product List not sorted ");
            unsortedList();
        }
    }
/*************************************  Executive Controller ********************************************/

    private ObservableList<Product> sortedProducts() {

        Product products[] = getData();
        Display SortedList = new DisplaySorted(new ExecutiveView());

        String names[] = SortedList.addData(products);

        List list = new ArrayList();
        for(int i = 0; i < products.length; i++){
            list.add(new Product(names[i]));
        }
        ObservableList data = FXCollections.observableList(list);
        return data;
}

    private ObservableList<Product> unSortedProducts() {

        Product products[] = getData();

        Display executiveView = new DisplayProducts( new ExecutiveView());
        String names[] = executiveView.addData(products);

        List list = new ArrayList();
        for(int i = 0; i < products.length; i++){
            list.add(new Product(names[i]));
        }

        ObservableList data = FXCollections.observableList(list);

        return data;
    }

    public void  tableCheked(){
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        if(sortTable.isSelected()){
            tableStatus.setText("Product list ordered alphabetically ");
            tableView.setItems(sortedProducts());

        }else {
            tableStatus.setText("Product list NOT ordered alphabetically ");
            tableView.setItems(unSortedProducts());
        }

    }

}

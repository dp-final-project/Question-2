package sample;

public interface View {
   String addLine(Product Product);

}

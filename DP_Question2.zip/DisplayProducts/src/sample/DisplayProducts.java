package sample;

public class DisplayProducts extends Display {

    public DisplayProducts( View view){
        super(view);
    }

    @Override
    public String[] addData(Product products[]) {
        String names[] = new String[products.length] ;
        for(int i =0 ; i < products.length; i++){
            Product product = products[i];
            names[i] = view.addLine(product);
        }
        return names;
    }
}


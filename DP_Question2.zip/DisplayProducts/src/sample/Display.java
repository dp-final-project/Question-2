package sample;

public abstract  class Display {
    protected View view;
    protected Display(View view){
        this.view = view;
    }
    public abstract String[] addData(Product products[]);
}

package sample;

import java.util.Arrays;

public class DisplaySorted extends Display{

    public DisplaySorted(View view){
        super(view);
    }

    public String[] addData(Product products[]) {
        String names[] = new String[products.length] ;
        for(int i =0 ; i < products.length; i++){
            Product product = products[i];
            names[i] = view.addLine(product);
        }
        Arrays.sort(names);
        return names;
    }

}

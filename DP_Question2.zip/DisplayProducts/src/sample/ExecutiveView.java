package sample;

public class ExecutiveView implements View {
    @Override
    public String addLine(Product product) {
        //trim
        //returns the name and quantity of the given product
        return product.getProductName() + "," +  product.getQuantity();

    }

}

package sample;

public class CustomerView implements View {

    @Override
    public String addLine(Product product) {
        //trim the string
        //returns name of the product
        return  product.getProductName();
}


}
